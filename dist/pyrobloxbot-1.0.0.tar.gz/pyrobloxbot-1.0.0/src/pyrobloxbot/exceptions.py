class NoRobloxWindowException(Exception):
    pass

class InvalidSlotNumberException(Exception):
    pass

class InvalidWalkDirectionException(Exception):
    pass